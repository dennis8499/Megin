---
name: megin-test-driven-development
description: Run Megin's outside-in behavior red-green-refactor loop for an approved task. Use for TDD, BDD, regression coverage, test-first development, 測試驅動、回歸測試; do not expand scope or waive a failing obligation.
---

# Megin test-driven development

Start from the approved behavior scenario. Add or update the smallest executable acceptance check,
run it red when a new behavior needs proof, then add the smallest implementation that makes it
green. Follow with inner unit or integration tests for the changed seam, refactor while green, and
rerun the focused command. Preserve raw output, exit status, source snapshot, and scenario ID in
the Work ID evidence.

Keep tests deterministic and meaningful. A parser success, skipped scenario, or unrelated passing
test is not behavior evidence. When a failure reveals a broader contract or scope change, stop and
return to planning; do not silently add code or tests outside the approved package.

Handoff: focused red/green evidence and a clean package result for implementation and review.
